# resources/lib/trakt/__init__.py
"""
Módulo Trakt - Integração com Trakt.tv
"""
from .trakt_sync import *
from .trakt_client import *