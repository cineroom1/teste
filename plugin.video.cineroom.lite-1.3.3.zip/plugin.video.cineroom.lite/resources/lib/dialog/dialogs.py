# -*- coding: utf-8 -*-
import xbmcgui
import xbmc
import re

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92

class DialogSelecaoFontes(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.item_data = kwargs.get('item_data')
        self.escolha = None
        self.todas_as_fontes = kwargs.get('fontes', [])
        
        # === CACHE DE LISTITEMS (OTIMIZAÇÃO) ===
        self._listitem_cache = {}
        
        # === PRÉ-PROCESSA QUALIDADES/IDIOMAS/PROVEDORES ===
        self._pre_processar_filtros()
        
        # Filtros atuais
        self.filtro_atual = "Todos"
        self.filtro_idioma_atual = "Todos"
        self.filtro_provedor_atual = "Todos"
    
    def _pre_processar_filtros(self):
        """
        Pré-processa TODAS as fontes UMA VEZ no init.
        Extrai qualidades, idiomas e provedores.
        """
        qualidades_set = set()
        idiomas_set = set()
        provedores_set = set()
        
        for fonte in self.todas_as_fontes:
            # Qualidade normalizada
            q = self._normalizar_qualidade(fonte.get('quality_label', ''))
            qualidades_set.add(q)
            
            # Idiomas
            langs = fonte.get('languages', 'LEG')
            for lang in langs.split('/'):
                lang = lang.strip()
                if lang and lang != 'N/A':
                    idiomas_set.add(lang)
            
            # Provedor
            provider = fonte.get('provider', '').strip()
            if provider:
                provedores_set.add(provider)
        
        # Ordena qualidades
        ordem_qualidade = ["4K", "1080p", "720p", "SD", "CAM", "scr", "sd", "Outros"]
        self.qualidades_disponiveis = ["Todos"] + sorted(
            qualidades_set,
            key=lambda q: ordem_qualidade.index(q) if q in ordem_qualidade else 99
        )
        
        self.idiomas_disponiveis = ["Todos"] + sorted(idiomas_set)
        if len(self.idiomas_disponiveis) == 1:
            self.idiomas_disponiveis.append("Original")
        
        self.provedores_disponiveis = ["Todos"] + sorted(provedores_set)
    
    @staticmethod
    def limpar_tags_kodi(texto):
        """Remove tags Kodi ([COLOR], [B], etc)"""
        if not texto:
            return ""
        return re.sub(r'\[/?(?:COLOR|B).*?\]', '', texto)
    
    def _normalizar_qualidade(self, q_string):
        """Normaliza string de qualidade (com cache)"""
        q_clean = self.limpar_tags_kodi(q_string).upper()
        
        # Ordem de verificação (mais específico primeiro)
        if '4K' in q_clean or '2160' in q_clean:
            return "4K"
        if '1080' in q_clean:
            return "1080p"
        if '720' in q_clean:
            return "720p"
        if 'CAM' in q_clean or 'CAMRIP' in q_clean:
            return "CAM"
        if 'SCR' in q_clean or 'SCREENER' in q_clean:
            return "scr"
        if '480' in q_clean or 'SD' in q_clean or 'DVD' in q_clean:
            return "sd"
        
        return "Outros"
    
    def _criar_listitem(self, fonte):
        """
        Cria ListItem com cache e label otimizado.
        """
        # Chave única para cache
        cache_key = fonte.get('url', '') or str(id(fonte))
    
        if cache_key in self._listitem_cache:
            return self._listitem_cache[cache_key]
    
        # Cria novo ListItem
        li = xbmcgui.ListItem(label="")  # Label vazio, vamos setar depois
    
        # Properties (mantenha para filtros/outros usos)
        qualidade_limpa = self._normalizar_qualidade(fonte.get('quality_label', ''))
        li.setProperty('quality', qualidade_limpa)
        li.setProperty('release_title', fonte.get('display_title'))
        li.setProperty('seeders', fonte.get('seeders_label'))
        li.setProperty('size', fonte.get('size'))
        li.setProperty('provider', fonte.get('provider'))
        li.setProperty('languages', fonte.get('languages'))
        li.setProperty('url_para_tocar', fonte.get('url'))
        li.setProperty('video_info', fonte.get('video_info'))
        li.setProperty('source', fonte.get('source', ''))
        li.setProperty('codec', fonte.get('codec', ''))
        li.setProperty('hdr', fonte.get('hdr', ''))
        li.setProperty('audio', fonte.get('audio', ''))
    
        # ===== CRIA LABEL OTIMIZADO =====
        title = fonte.get('display_title', 'Sem título')
    
        # Cria string técnica compacta
        tech_parts = []
    
        # Qualidade
        if qualidade_limpa and qualidade_limpa != "Outros":
            tech_parts.append(f"[B][COLOR FF3399FF]{qualidade_limpa}[/COLOR][/B]")
    
        # Codec
        codec = fonte.get('codec', '')
        if codec:
            tech_parts.append(f"[COLOR FFFFCC00]{codec}[/COLOR]")
    
        # HDR (só se for HDR)
        hdr = fonte.get('hdr', '')
        if hdr and hdr.upper() != 'SDR':
            tech_parts.append(f"[COLOR FF00FF00]{hdr}[/COLOR]")
    
        # Áudio (abreviado)
        audio = fonte.get('audio', '')
        if audio:
            audio_short = self._abreviar_audio(audio)
            tech_parts.append(f"[COLOR FF66CCFF]{audio_short}[/COLOR]")
    
        # Source
        source = fonte.get('source', '')
        if source:
            tech_parts.append(f"[COLOR FFCC66FF]{source}[/COLOR]")
    
        # Juntar partes técnicas
        tech_str = ""
        if tech_parts:
            tech_str = " | ".join(tech_parts) + "\n"
    
        # Info de seeds e tamanho
        stats_parts = []
        seeders = fonte.get('seeders_label', '')
        if seeders:
            stats_parts.append(f"Seeds: [B]{seeders}[/B]")
    
        size = fonte.get('size', '')
        if size:
            stats_parts.append(f"Tamanho: [B]{size}[/B]")
    
        stats_str = " | ".join(stats_parts)
    
        # Provider e idioma
        provider = fonte.get('provider', '')
        languages = fonte.get('languages', '')
        
        meta_str = ""
        if provider or languages:
            meta_parts = []
            if provider:
                meta_parts.append(f"Provedor: [B][COLOR FF00FFFF]{provider}[/COLOR][/B]")
            if languages:
                meta_parts.append(f"Idioma: [B]{languages}[/B]")
            meta_str = " | ".join(meta_parts)
    
        # Label final (3 linhas máximo)
        label_lines = []
    
        # Linha 1: Info técnica
        if tech_str.strip():
            label_lines.append(tech_str.strip())
    
        # Linha 2: Título principal
        label_lines.append(f"[B]{title}[/B]")
    
        # Linha 3: Stats + metadata
        line3_parts = []
        if stats_str:
            line3_parts.append(stats_str)
        if meta_str:
            line3_parts.append(meta_str)
    
        if line3_parts:
            label_lines.append(" | ".join(line3_parts))
    
        # Junta tudo
        final_label = "\n".join(label_lines)
        li.setLabel(final_label)
    
        # Salva no cache
        self._listitem_cache[cache_key] = li
    
        return li

    def _abreviar_audio(self, audio_string):
        """Abrevia strings de áudio comuns para economizar espaço"""
        audio_lower = audio_string.lower()
    
        # Mapeamento de abreviações
        abbrev_map = {
            'dolby digital': 'DD',
            'dd 5.1': 'DD5.1',
            'ac3': 'DD',
            'dolby atmos': 'Atmos',
            'dts-hd master audio': 'DTS-HD',
            'dts-hd': 'DTS-HD',
            'dts': 'DTS',
            'aac': 'AAC',
            'truehd': 'TrueHD',
            'flac': 'FLAC',
            'mp3': 'MP3',
            'opus': 'Opus'
        }
    
        # Procura por correspondências
        for key, abbrev in abbrev_map.items():
            if key in audio_lower:
                return abbrev
    
        # Se não encontrar, retorna primeiros 6 caracteres
        return audio_string[:6]
    
    def _atualizar_labels_filtros(self):
        """Atualiza labels dos botões de filtro"""
        try:
            q = self.filtro_atual if self.filtro_atual != "Todos" else "Qualidade"
            i = self.filtro_idioma_atual if self.filtro_idioma_atual != "Todos" else "Idioma"
            p = self.filtro_provedor_atual if self.filtro_provedor_atual != "Todos" else "Provedor"
            
            self.getControl(1300).setLabel(q)
            self.getControl(1400).setLabel(i)
            self.getControl(1500).setLabel(p)
        except Exception as e:
            xbmc.log(f"[Dialogs] Erro ao atualizar labels: {e}", xbmc.LOGERROR)
    
    def onInit(self):
        """Inicialização do dialog"""
        try:
            # ===================================
            # ✅ ARTE DE FUNDO + CLEARLOGO
            # ===================================
            if self.item_data:
                # Fanart (backdrop)
                fanart = self.item_data.get('backdrop', '') or self.item_data.get('fanart', '')
                if fanart:
                    self.setProperty('info.fanart', fanart)
                
                # Clearlogo (prioritário)
                clearlogo = self.item_data.get('clearlogo', '')
                if clearlogo:
                    self.setProperty('info.clearlogo', clearlogo)
                
                # Título (fallback se não tiver clearlogo)
                title = self.item_data.get('title', '') or self.item_data.get('name', '')
                if title:
                    self.setProperty('info.title', title)
            
            # Atualiza labels dos filtros
            self._atualizar_labels_filtros()
            
            # Popula lista (primeira vez)
            self.popular_lista_fontes()
            
            # Foco no primeiro filtro
            self.setFocusId(1300)
            
        except Exception as e:
            xbmc.log(f"[Dialogs] Erro no onInit: {e}", xbmc.LOGERROR)
    
    def popular_lista_fontes(self):
        """
        Popula lista de fontes (OTIMIZADO).
        Usa cache de ListItems + filtro rápido.
        """
        try:
            lista_control = self.getControl(1000)
            lista_control.reset()
            
            # === FILTRO OTIMIZADO (uma passagem) ===
            fontes_filtradas = []
            
            for fonte in self.todas_as_fontes:
                # Filtro de qualidade
                if self.filtro_atual != "Todos":
                    if self._normalizar_qualidade(fonte.get('quality_label', '')) != self.filtro_atual:
                        continue
                
                # Filtro de idioma
                if self.filtro_idioma_atual != "Todos":
                    if self.filtro_idioma_atual not in fonte.get('languages', ''):
                        continue
                
                # Filtro de provedor
                if self.filtro_provedor_atual != "Todos":
                    if fonte.get('provider', '') != self.filtro_provedor_atual:
                        continue
                
                fontes_filtradas.append(fonte)
            
            # === ADICIONA ITENS (usando cache) ===
            for fonte in fontes_filtradas:
                li = self._criar_listitem(fonte)
                lista_control.addItem(li)
            
        except Exception as e:
            xbmc.log(f"[Dialogs] Erro ao popular lista: {e}", xbmc.LOGERROR)
    
    def onClick(self, controlId):
        """Handler de cliques"""
        dialog = xbmcgui.Dialog()
        
        if controlId == 1000:
            # Seleção de fonte
            item = self.getControl(1000).getSelectedItem()
            if item:
                self.escolha = item.getProperty('url_para_tocar')
                self.close()
        
        elif controlId == 1300:
            # Filtro de qualidade
            escolha_idx = dialog.select('Filtrar por Qualidade', self.qualidades_disponiveis)
            if escolha_idx > -1:
                self.filtro_atual = self.qualidades_disponiveis[escolha_idx]
                self.popular_lista_fontes()
                self._atualizar_labels_filtros()
        
        elif controlId == 1400:
            # Filtro de idioma
            escolha_idx = dialog.select('Filtrar por Idioma', self.idiomas_disponiveis)
            if escolha_idx > -1:
                self.filtro_idioma_atual = self.idiomas_disponiveis[escolha_idx]
                self.popular_lista_fontes()
                self._atualizar_labels_filtros()
        
        elif controlId == 1500:
            # Filtro de provedor
            escolha_idx = dialog.select('Filtrar por Provedor', self.provedores_disponiveis)
            if escolha_idx > -1:
                self.filtro_provedor_atual = self.provedores_disponiveis[escolha_idx]
                self.popular_lista_fontes()
                self._atualizar_labels_filtros()
    
    def onAction(self, action):
        """Handler de ações (back, esc, etc)"""
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.close()